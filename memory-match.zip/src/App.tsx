/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo, ComponentType } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Flame,
  Crown,
  Sprout,
  Sparkles,
  Heart,
  Gamepad2,
  Anchor,
  Sun,
  Trophy,
  RotateCcw,
  Timer,
  Zap,
  HelpCircle,
  Award,
  CheckCircle2,
  Sparkle
} from 'lucide-react';

/* ==========================================================================
   CUSTOMIZATION CONFIGURATION
   ==========================================================================
   You can easily customize the theme, colors, or card content of your game 
   by modifying this section.
   
   To use Emojis instead of Lucide Icons:
   1. Change CARD_DESIGNS to contain emojis, e.g., { symbol: '🔥', color: 'bg-orange-50' }
   2. Update the MemoryCard component below to render {card.iconName} directly.
   ========================================================================== */

interface CardDesign {
  iconName: string;
  // Tailwind color combinations for beautiful, themed front faces
  colorClass: string;
  glowClass: string;
}

const CARD_DESIGNS: CardDesign[] = [
  { iconName: 'Flame', colorClass: 'bg-orange-400 border-orange-600 ring-orange-200', glowClass: 'shadow-orange-200/50' },
  { iconName: 'Crown', colorClass: 'bg-yellow-400 border-yellow-600 ring-yellow-200', glowClass: 'shadow-yellow-200/50' },
  { iconName: 'Sprout', colorClass: 'bg-emerald-400 border-emerald-600 ring-emerald-200', glowClass: 'shadow-emerald-200/50' },
  { iconName: 'Sparkles', colorClass: 'bg-purple-400 border-purple-600 ring-purple-200', glowClass: 'shadow-purple-200/50' },
  { iconName: 'Heart', colorClass: 'bg-rose-400 border-rose-600 ring-rose-200', glowClass: 'shadow-rose-200/50' },
  { iconName: 'Gamepad2', colorClass: 'bg-indigo-400 border-indigo-600 ring-indigo-200', glowClass: 'shadow-indigo-200/50' },
  { iconName: 'Anchor', colorClass: 'bg-sky-400 border-sky-600 ring-sky-200', glowClass: 'shadow-sky-200/50' },
  { iconName: 'Sun', colorClass: 'bg-amber-400 border-amber-600 ring-amber-200', glowClass: 'shadow-amber-200/50' },
];

// Mapping string names to Lucide Icon components for dynamic rendering
const ICON_MAP: Record<string, ComponentType<any>> = {
  Flame,
  Crown,
  Sprout,
  Sparkles,
  Heart,
  Gamepad2,
  Anchor,
  Sun,
};

type Difficulty = 'easy' | 'medium' | 'hard';

interface DifficultySetting {
  pairs: number;
  gridCols: string;
  label: string;
}

const DIFFICULTY_SETTINGS: Record<Difficulty, DifficultySetting> = {
  easy: { pairs: 4, gridCols: 'grid-cols-4', label: 'Easy (4 Pairs)' },
  medium: { pairs: 6, gridCols: 'grid-cols-3 sm:grid-cols-4', label: 'Medium (6 Pairs)' },
  hard: { pairs: 8, gridCols: 'grid-cols-4', label: 'Hard (8 Pairs)' },
};

interface Card {
  id: string;
  iconName: string;
  colorClass: string;
  glowClass: string;
  isFlipped: boolean;
  isMatched: boolean;
}

export default function App() {
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [cards, setCards] = useState<Card[]>([]);
  const [firstChoice, setFirstChoice] = useState<Card | null>(null);
  const [secondChoice, setSecondChoice] = useState<Card | null>(null);
  const [disabled, setDisabled] = useState<boolean>(false);
  
  // Game metrics
  const [moves, setMoves] = useState<number>(0);
  const [seconds, setSeconds] = useState<number>(0);
  const [gameStarted, setGameStarted] = useState<boolean>(false);
  const [isWon, setIsWon] = useState<boolean>(false);

  // Animation states for immediate feedback (juice)
  const [mismatchedIds, setMismatchedIds] = useState<string[]>([]);
  const [justMatchedIds, setJustMatchedIds] = useState<string[]>([]);

  // High score stats loaded from localStorage
  const [bestMoves, setBestMoves] = useState<number | null>(null);
  const [bestTime, setBestTime] = useState<number | null>(null);

  // Load high scores when difficulty changes
  useEffect(() => {
    const savedMoves = localStorage.getItem(`memory_match_best_moves_${difficulty}`);
    const savedTime = localStorage.getItem(`memory_match_best_time_${difficulty}`);
    setBestMoves(savedMoves ? parseInt(savedMoves, 10) : null);
    setBestTime(savedTime ? parseInt(savedTime, 10) : null);
  }, [difficulty]);

  // Initial setup and resets
  const initializeGame = (diff: Difficulty = difficulty) => {
    const config = DIFFICULTY_SETTINGS[diff];
    // Take required number of card designs for the difficulty
    const selectedDesigns = CARD_DESIGNS.slice(0, config.pairs);
    
    // Create matching pairs
    const pairs = [...selectedDesigns, ...selectedDesigns].map((design, index) => ({
      id: `${design.iconName}-${index}`,
      iconName: design.iconName,
      colorClass: design.colorClass,
      glowClass: design.glowClass,
      isFlipped: false,
      isMatched: false,
    }));

    // Fisher-Yates Shuffle
    for (let i = pairs.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pairs[i], pairs[j]] = [pairs[j], pairs[i]];
    }

    setCards(pairs);
    setFirstChoice(null);
    setSecondChoice(null);
    setDisabled(false);
    setMoves(0);
    setSeconds(0);
    setGameStarted(false);
    setIsWon(false);
    setMismatchedIds([]);
    setJustMatchedIds([]);
  };

  // Start game on mount
  useEffect(() => {
    initializeGame();
  }, [difficulty]);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (gameStarted && !isWon) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [gameStarted, isWon]);

  // Handle card click / choice
  const handleChoice = (clickedCard: Card) => {
    if (disabled || clickedCard.isFlipped || clickedCard.isMatched) return;

    // Start timer on first interaction
    if (!gameStarted) {
      setGameStarted(true);
    }

    // Flip the clicked card immediately in state
    setCards((prevCards) =>
      prevCards.map((card) =>
        card.id === clickedCard.id ? { ...card, isFlipped: true } : card
      )
    );

    if (!firstChoice) {
      setFirstChoice(clickedCard);
    } else {
      setSecondChoice(clickedCard);
      setMoves((prev) => prev + 1);
      setDisabled(true);

      // Check if cards match
      if (firstChoice.iconName === clickedCard.iconName) {
        // MATCH FOUND
        setCards((prevCards) =>
          prevCards.map((card) =>
            card.iconName === clickedCard.iconName
              ? { ...card, isMatched: true }
              : card
          )
        );
        
        // Trigger pulse animation
        setJustMatchedIds([firstChoice.id, clickedCard.id]);
        
        // Check if game is completely won
        setTimeout(() => {
          setJustMatchedIds([]);
          resetTurn();

          // Check if all cards matched
          setCards((currentCards) => {
            const allMatched = currentCards.every((c) => c.isMatched || c.id === clickedCard.id || c.id === firstChoice.id);
            if (allMatched) {
              handleWin();
            }
            return currentCards;
          });
        }, 600);

      } else {
        // MISMATCH
        setMismatchedIds([firstChoice.id, clickedCard.id]);
        
        setTimeout(() => {
          // Flip back down
          setCards((prevCards) =>
            prevCards.map((card) =>
              card.id === firstChoice.id || card.id === clickedCard.id
                ? { ...card, isFlipped: false }
                : card
            )
          );
          setMismatchedIds([]);
          resetTurn();
        }, 1000);
      }
    }
  };

  const resetTurn = () => {
    setFirstChoice(null);
    setSecondChoice(null);
    setDisabled(false);
  };

  const handleWin = () => {
    setIsWon(true);
    
    // Check and save High Scores in localStorage
    const savedMoves = localStorage.getItem(`memory_match_best_moves_${difficulty}`);
    const savedTime = localStorage.getItem(`memory_match_best_time_${difficulty}`);

    const isNewBestMoves = !savedMoves || moves + 1 < parseInt(savedMoves, 10);
    const isNewBestTime = !savedTime || seconds < parseInt(savedTime, 10);

    if (isNewBestMoves) {
      localStorage.setItem(`memory_match_best_moves_${difficulty}`, (moves + 1).toString());
      setBestMoves(moves + 1);
    }
    if (isNewBestTime) {
      localStorage.setItem(`memory_match_best_time_${difficulty}`, seconds.toString());
      setBestTime(seconds);
    }
  };

  // Format time as MM:SS
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Calculate current matched pairs count
  const matchedCount = useMemo(() => {
    return cards.filter((card) => card.isMatched).length / 2;
  }, [cards]);

  return (
    <div id="game-root" className="min-h-screen bg-yellow-50 text-slate-800 flex flex-col justify-between p-4 sm:p-8 font-sans border-8 border-yellow-200 overflow-x-hidden">
      
      {/* HEADER SECTION - VIBRANT THEME */}
      <header className="max-w-4xl w-full mx-auto flex flex-col md:flex-row items-center justify-between px-6 sm:px-12 py-6 sm:py-8 bg-white border-b-4 border-yellow-100 shadow-sm rounded-[32px] mb-4 sm:mb-6">
        <div className="flex flex-col text-center md:text-left mb-4 md:mb-0">
          <h1 id="game-title" className="text-4xl sm:text-5xl font-black text-pink-500 tracking-tighter uppercase leading-none">
            ME-MO-RY <span className="text-teal-400 font-medium italic lowercase text-2xl ml-1">match-it!</span>
          </h1>
          <p id="game-subtitle" className="text-slate-400 font-bold uppercase text-xs tracking-widest mt-1.5">
            Level: {difficulty === 'easy' ? 'Tropical Island (Easy)' : difficulty === 'medium' ? 'Blue Horizon (Medium)' : 'Volcanic Peak (Hard)'}
          </p>
        </div>
        
        {/* Playful Stats Badges */}
        <div className="flex gap-4 sm:gap-6">
          <div className="text-center" id="stat-moves">
            <p className="text-gray-400 text-xs font-black uppercase mb-1">Moves</p>
            <p className="bg-pink-500 text-white text-2xl sm:text-3xl font-black px-4 py-1.5 rounded-2xl shadow-lg border-b-4 border-pink-700 tabular-nums min-w-[70px]">
              {moves}
            </p>
          </div>
          <div className="text-center" id="stat-matches">
            <p className="text-gray-400 text-xs font-black uppercase mb-1">Matches</p>
            <p className="bg-teal-400 text-white text-2xl sm:text-3xl font-black px-4 py-1.5 rounded-2xl shadow-lg border-b-4 border-teal-600 tabular-nums min-w-[70px]">
              {matchedCount}/{DIFFICULTY_SETTINGS[difficulty].pairs}
            </p>
          </div>
          <div className="text-center" id="stat-best">
            <p className="text-gray-400 text-xs font-black uppercase mb-1">Best</p>
            <p className="bg-orange-400 text-white text-2xl sm:text-3xl font-black px-4 py-1.5 rounded-2xl shadow-lg border-b-4 border-orange-700 tabular-nums min-w-[70px]">
              {bestMoves !== null ? bestMoves : '—'}
            </p>
          </div>
        </div>
      </header>

      {/* MAIN GAME CONTAINER */}
      <main className="max-w-4xl w-full mx-auto flex-1 flex flex-col justify-center gap-6">
        
        {/* INTERACTIVE CARDS GRID */}
        <section id="game-grid-container" className="flex-1 flex items-center justify-center py-2 sm:py-4">
          <div className="bg-white/40 p-4 sm:p-8 rounded-[40px] shadow-inner border-4 border-yellow-200/50 w-full max-w-3xl">
            <div
              id="cards-grid"
              className={`grid ${DIFFICULTY_SETTINGS[difficulty].gridCols} gap-3 sm:gap-6 w-full`}
            >
              <AnimatePresence mode="popLayout">
                {cards.map((card) => {
                  const IconComponent = ICON_MAP[card.iconName];
                  const isMismatched = mismatchedIds.includes(card.id);
                  const isJustMatched = justMatchedIds.includes(card.id);

                  return (
                    <div
                      key={card.id}
                      id={`card-container-${card.id}`}
                      className="relative aspect-[3/4] w-full"
                      style={{ perspective: '1000px' }}
                    >
                      <motion.button
                        id={`card-btn-${card.id}`}
                        onClick={() => handleChoice(card)}
                        className="w-full h-full text-left relative focus:outline-none cursor-pointer"
                        disabled={disabled || card.isFlipped || card.isMatched}
                        style={{ transformStyle: 'preserve-3d' }}
                        animate={{
                          rotateY: card.isFlipped || card.isMatched ? 180 : 0,
                          x: isMismatched ? [0, -6, 6, -6, 6, 0] : 0,
                          scale: isJustMatched ? [1, 1.15, 1] : 1,
                        }}
                        whileHover={
                          !card.isFlipped && !card.isMatched
                            ? { scale: 1.04, y: -4 }
                            : {}
                        }
                        transition={{
                          rotateY: { duration: 0.4, ease: 'easeInOut' },
                          x: { duration: 0.4, ease: 'easeInOut' },
                          scale: { duration: 0.4, ease: 'easeInOut' },
                        }}
                      >
                        {/* CARD BACKFACE (Face Down) - Vibrant Teal theme */}
                        <div
                          id={`card-back-${card.id}`}
                          className="absolute inset-0 rounded-3xl bg-teal-400 shadow-xl border-b-[8px] sm:border-b-[10px] border-r-4 border-teal-600 flex flex-col items-center justify-center cursor-pointer select-none"
                          style={{ backfaceVisibility: 'hidden' }}
                        >
                          {/* Inner decorative circle with ? */}
                          <div className="w-12 h-12 sm:w-20 sm:h-20 border-4 sm:border-8 border-white/30 rounded-full flex items-center justify-center bg-teal-500/10">
                            <span className="text-white font-black text-xl sm:text-4xl">?</span>
                          </div>
                        </div>

                        {/* CARD FRONTFACE (Face Up) - Colorful juicy themes */}
                        <div
                          id={`card-front-${card.id}`}
                          className={`absolute inset-0 rounded-3xl shadow-xl flex items-center justify-center cursor-default select-none border-b-[8px] sm:border-b-[10px] border-r-4 transition-all duration-300 ${
                            card.isMatched
                              ? 'bg-white border-gray-100 grayscale opacity-40 scale-95 ring-0'
                              : `${card.colorClass} border-slate-700/10 ring-4 sm:ring-8`
                          }`}
                          style={{
                            backfaceVisibility: 'hidden',
                            transform: 'rotateY(180deg)',
                          }}
                        >
                          {IconComponent ? (
                            <motion.div
                              animate={card.isMatched ? { scale: [1, 1.1, 1] } : {}}
                              transition={{ duration: 0.3 }}
                              className={card.isMatched ? 'text-slate-400' : 'text-white'}
                            >
                              <IconComponent className="w-10 h-10 sm:w-16 sm:h-16 stroke-[3]" />
                            </motion.div>
                          ) : null}

                          {/* Subtle mini checkmark overlay for matched cards */}
                          {card.isMatched && (
                            <div className="absolute top-2 right-2 text-emerald-500">
                              <CheckCircle2 className="w-5 h-5 fill-emerald-100" />
                            </div>
                          )}
                        </div>
                      </motion.button>
                    </div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        </section>

      </main>

      {/* FOOTER & CONTROLS - VIBRANT STYLE */}
      <footer className="max-w-4xl w-full mx-auto flex flex-col sm:flex-row items-center justify-between p-6 sm:p-10 gap-6 sm:gap-4 mt-4">
        <div className="flex items-center gap-3 text-slate-500 font-bold uppercase text-xs sm:text-sm">
          <div className="w-3.5 h-3.5 rounded-full bg-teal-400 animate-pulse"></div>
          <span>Time: {formatTime(seconds)}</span>
        </div>

        {/* Playful Restart Button */}
        <button
          id="btn-restart"
          onClick={() => initializeGame()}
          className="bg-orange-500 hover:bg-orange-600 text-white font-black text-lg sm:text-2xl px-8 sm:px-12 py-3 sm:py-4 rounded-3xl shadow-2xl border-b-8 border-orange-800 flex items-center gap-3 active:border-b-4 active:translate-y-1 transition-all duration-150 cursor-pointer"
        >
          RESTART GAME
          <RotateCcw className="w-6 h-6 stroke-[3.5]" />
        </button>

        {/* Playful Difficulty Selector */}
        <div className="flex items-center gap-2 bg-yellow-100/80 p-1.5 rounded-2xl border border-yellow-200">
          {(Object.keys(DIFFICULTY_SETTINGS) as Difficulty[]).map((diff) => (
            <button
              id={`btn-diff-${diff}`}
              key={diff}
              onClick={() => setDifficulty(diff)}
              className={`px-3 py-1.5 text-xs font-black uppercase rounded-xl transition-all duration-200 cursor-pointer ${
                difficulty === diff
                  ? 'bg-pink-500 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {diff}
            </button>
          ))}
        </div>
      </footer>

      {/* VICTORY MODAL OVERLAY */}
      <AnimatePresence>
        {isWon && (
          <motion.div
            id="victory-overlay"
            className="fixed inset-0 bg-slate-900/50 backdrop-blur-md z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              id="victory-card"
              className="bg-white rounded-[40px] p-6 sm:p-8 max-w-md w-full shadow-2xl border-8 border-yellow-200 text-center relative overflow-hidden"
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            >
              {/* Particle Sparkle FX */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-full h-full relative">
                  <motion.div
                    className="absolute top-12 left-12 text-yellow-400"
                    animate={{ scale: [1, 1.5, 1], rotate: [0, 90, 0] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                  >
                    <Sparkle className="w-5 h-5 fill-yellow-400" />
                  </motion.div>
                  <motion.div
                    className="absolute top-16 right-16 text-indigo-400"
                    animate={{ scale: [1, 1.5, 1], rotate: [0, -90, 0] }}
                    transition={{ repeat: Infinity, duration: 2.4, delay: 0.5 }}
                  >
                    <Sparkle className="w-4 h-4 fill-indigo-400" />
                  </motion.div>
                  <motion.div
                    className="absolute bottom-20 left-20 text-rose-400"
                    animate={{ scale: [1, 1.4, 1] }}
                    transition={{ repeat: Infinity, duration: 1.8, delay: 0.2 }}
                  >
                    <Sparkle className="w-4 h-4 fill-rose-400" />
                  </motion.div>
                </div>
              </div>

              {/* Award / Medal Graphic */}
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-yellow-400 to-amber-400 flex items-center justify-center shadow-md shadow-yellow-100 mb-5 relative">
                <Award className="w-10 h-10 text-white" />
                <motion.div
                  className="absolute -inset-1 rounded-full border-2 border-yellow-400/30"
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                />
              </div>

              <h2 id="victory-title" className="text-3xl font-black text-pink-500 tracking-tighter uppercase mb-2">
                Spectacular Match!
              </h2>
              <p id="victory-subtitle" className="text-sm font-bold text-slate-400 uppercase tracking-wide mb-6">
                You successfully matched all cards on the <span className="text-teal-400">{difficulty}</span> grid.
              </p>

              {/* STATS MATRIX */}
              <div className="grid grid-cols-2 gap-3 mb-6 bg-yellow-50/50 p-4 rounded-3xl border border-yellow-100">
                <div className="flex flex-col items-center p-2 border-r border-yellow-100">
                  <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">
                    Moves Played
                  </span>
                  <span className="text-2xl font-black text-pink-500 tabular-nums">
                    {moves}
                  </span>
                </div>
                <div className="flex flex-col items-center p-2">
                  <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">
                    Time Taken
                  </span>
                  <span className="text-2xl font-black text-teal-400 tabular-nums">
                    {formatTime(seconds)}
                  </span>
                </div>
              </div>

              {/* High Score Celebration */}
              {(bestMoves === moves || bestTime === seconds) && (
                <div className="mb-6 flex items-center justify-center gap-1.5 bg-yellow-100 border border-yellow-200 text-yellow-800 py-2.5 px-4 rounded-2xl text-xs font-black uppercase tracking-wide animate-pulse">
                  <Trophy className="w-4 h-4 text-amber-500 fill-amber-500" />
                  New Record Achieved!
                </div>
              )}

              {/* ACTION BUTTONS */}
              <div className="flex flex-col gap-2">
                <button
                  id="btn-play-again"
                  onClick={() => initializeGame()}
                  className="w-full flex items-center justify-center gap-2 py-3.5 px-5 text-sm font-black uppercase tracking-wider text-white bg-indigo-600 hover:bg-indigo-500 active:scale-98 rounded-2xl transition-all duration-200 shadow-lg cursor-pointer"
                >
                  Play Again
                </button>
                <button
                  id="btn-close-victory"
                  onClick={() => setIsWon(false)}
                  className="w-full py-3 px-5 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-slate-600 rounded-xl transition-all duration-200 cursor-pointer"
                >
                  View Completed Grid
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
